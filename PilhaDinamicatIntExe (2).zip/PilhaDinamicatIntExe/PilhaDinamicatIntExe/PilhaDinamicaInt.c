#include "PilhaDinamicaInt.h"

Pilha* criar_pilha() {
    Pilha *p = malloc(sizeof(Pilha));
    if (p != NULL){
        p->topo = NULL;
    }
    return p;

}

void liberar_pilha(Pilha *p) {

}

int empilhar(Pilha *p, int valor) {
    if (p != NULL){
        return 0;
    }
    No *no = malloc(sizeof(No));
    if (no != NULL){
        no->dado = valor;
        no->prox = p->topo;
        p->topo = no;
        return 1;
    }
    else {
        return 0;
    }

}

int desempilhar(Pilha *p, int *valor) {

}

int retornar_topo(Pilha *p, int *valor) {

}

int tamanho_pilha(Pilha *p) {

}

void imprimir_pilha(Pilha *p) {

}
